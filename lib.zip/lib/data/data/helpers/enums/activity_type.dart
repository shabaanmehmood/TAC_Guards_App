enum ActivityType { review, other }
