class AppAssets {
  // Images.

  // Icons.
  static String kArrowForward = 'assets/icon/forwardarrow.svg';
  static String kPhone = 'assets/icon/call.svg';
  static String kEmail = 'assets/icon/email.svg';
  static String kGalleryAdd = 'assets/icon/galleryadd.svg';
  static String kLocation = 'assets/icon/location.svg';
  static String kPassword = 'assets/icon/lock.svg';
  static String kEyeIconCross = 'assets/icon/eye-slash.svg';
  static String kPerson = 'assets/icon/person.svg';
  static String kPersonalCard = 'assets/icon/personalcard.svg';
  static String kAlerts = 'assets/icon/notification.svg';
  static String kHome = 'assets/icon/map.svg';
  static String kGuards = 'assets/icon/Group.svg';
  static String kJobs = 'assets/icon/archive-book.svg';
  static String kMessages = 'assets/icon/direct.svg';
  static String kAccount = 'assets/icon/frame.svg';

  static String kFilter = 'assets/icon/filter.png';
  static String kCross = 'assets/icon/cross.png';
  static String kSearch = 'assets/icon/search.png';
  // static String kFaceBook = 'assets/icons/facebook.svg';
  // static String kGoogle = 'assets/icons/google.svg';
  // static String kMail = 'assets/icons/mail.svg';
  // static String kHome = 'assets/icons/home.svg';
  // static String kSearch = 'assets/icons/search.svg';
  // static String kPopular = 'assets/icons/popular.svg';
  // static String kRecords = 'assets/icons/records.svg';
  // static String kStatistics = 'assets/icons/statistics.svg';
  // static String kStudents = 'assets/icons/students.svg';
  // static String kBookMark = 'assets/icons/bookmark.svg';
  // static String kCrown = 'assets/icons/crown.svg';
  // static String kBookOpen = 'assets/icons/book-open.svg';
  // static String kBookOpenFilled = 'assets/icons/book-open-filled.svg';
  // static String kFilter = 'assets/icons/filter.svg';
  // static String kUser = 'assets/icons/user.svg';
  // static String kUserFilled = 'assets/icons/user-filled.svg';
  // static String kMoreVert = 'assets/icons/more_vert.svg';
  // static String kProfile = 'assets/icons/profile.svg';
  // static String kEmail = 'assets/icons/e-mail.svg';
  // static String kPassword = 'assets/icons/password.svg';
  // static String kNotifications = 'assets/icons/notification.svg';
  // static String kTheme = 'assets/icons/theme.svg';
  // static String kDownload = 'assets/icons/download.svg';
  // static String kHelp = 'assets/icons/help.svg';
  // static String kPrivacy = 'assets/icons/privacy.svg';
  // static String kActivity = 'assets/icons/activity.svg';
  // static String kActivityFilled = 'assets/icons/activity-filled.svg';
  // static String kFollow = 'assets/icons/follow.svg';
  // static String kMessage = 'assets/icons/message.svg';
  // static String kLinks = 'assets/icons/links.svg';
  // static String kAdd = 'assets/icons/add.svg';
  // static String kFrown = 'assets/icons/frown.svg';
  // static String kAngry = 'assets/icons/angry.svg';
  // static String kHappy = 'assets/icons/happy.svg';
  // static String kNeutral = 'assets/icons/neutral.svg';
  // static String kSmile = 'assets/icons/smile.svg';
  // static String kThumbUp = 'assets/icons/thumb-up.svg';
  // static String kComment = 'assets/icons/comment.svg';
  // static String kWorkVector = 'assets/images/vector.png';
  //
  //
  // // Categories.
  // static String kGaming = 'assets/icons/gaming.svg';
  // static String kMusic = 'assets/icons/music.svg';
  // static String kPhotography = 'assets/icons/photography.svg';
  // static String kArt = 'assets/icons/art.svg';
  // static String kDesign = 'assets/icons/design.svg';
  // static String kBusiness = 'assets/icons/business.svg';
  // static String kLifeStyle = 'assets/icons/lifestyle.svg';
  // static String kCoding = 'assets/icons/coding.svg';
  // static String kCalendar = 'assets/icons/calendar.svg';
  // static String kTriangleUp = 'assets/icons/triangle-up.svg';
  //
  // // Images.
  // static String kTeacher1 = 'assets/images/teacher1.jpg';
  // static String kFlutterCourse1 = 'assets/images/flutter-course-1.png';
  // static String kWebsiteCourse1 = 'assets/images/website-course-1.jpg';
  // static String kContrast = 'assets/images/contrast.png';
  // static String kRepetition = 'assets/images/repetition.png';
  // static String kSymmetry = 'assets/images/symmetry.png';
  // static String kUser1 = 'assets/images/user1.jpg';
  // static String kUser2 = 'assets/images/user2.jpg';
  // static String kUser3 = 'assets/images/user3.jpg';
  // static String kUser4 = 'assets/images/user4.jpg';
  // static String kUser5 = 'assets/images/user5.jpg';
  // static String kUser6 = 'assets/images/user6.jpg';
  // static String kUser7 = 'assets/images/user7.jpg';
  // static String kNoData = 'assets/images/no_data.png';
  // static String kOnboarding1 = 'assets/images/onboarding_1.png';
  // static String kOnboarding2 = 'assets/images/onboarding_2.png';
  // static String kOnboarding3 = 'assets/images/onboarding_3.png';
  // static String kStudent = 'assets/images/student.png';
  // static String kTeacher = 'assets/images/teacher.png';
  // static String kStoreSetup = 'assets/images/store_setup.png';
  // static String kStoreSet = 'assets/images/store_set.png';
  // static String kProject = 'assets/images/project.png';
  // static String kTrueGigs = 'assets/images/icon_new.png';

  static String kTacLogo = 'assets/logo.png';
  static String kTacHomeScreenLogo = 'assets/logoforhomescreen.png';
  static String kUserPicture = 'assets/userpicture.jpg';
  static String kAppleLogo = 'assets/apple.png';
  static String kGoogleLogo = 'assets/google.png';
  static String kMapPicture = 'assets/otp.png';
}
