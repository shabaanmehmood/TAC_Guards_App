import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:tac/data/data/constants/app_assets.dart';
import 'package:tac/data/data/constants/app_colors.dart';
import 'package:tac/data/data/constants/app_spacing.dart';
import 'package:tac/data/data/constants/app_typography.dart';

class JobCard extends StatelessWidget {
  final String jobTitle;
  final String perHourRate;
  final String companyName;
  final String rating;
  final String hiringTag;
  final String jobType;
  final String location;
  final String distance;
  final String day;
  final String shiftTime;
  final String requiredPersons;
  final String jobDept;

  const JobCard({
    Key? key,
    required this.jobTitle,
    required this.perHourRate,
    required this.companyName,
    required this.rating,
    required this.hiringTag,
    required this.jobType,
    required this.location,
    required this.distance,
    required this.day,
    required this.shiftTime,
    required this.requiredPersons,
    required this.jobDept,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.only(right: 20, bottom: 10, top: 20, left: 20),
      decoration: BoxDecoration(
        color: AppColors.kJobCardColor, // Dark background color
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          /// **Job Title & Per Hour Rate**
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                jobTitle,
                style: AppTypography.kBold16.copyWith(
                  color: AppColors.kWhite,
                )
              ),
              Text(
                perHourRate,
                style: AppTypography.kBold16.copyWith(
                  color: AppColors.kSkyBlue
                )
              ),
            ],
          ),
          SizedBox(height: AppSpacing.fiveVertical),
          /// **Company Name & Rating**
          Row(
            children: [
              Text(
                companyName,
                style: AppTypography.kLight14.copyWith(
                  color: AppColors.kWhite
                )
              ),
              const SizedBox(width: 5),
              Text(
                rating,
                style: AppTypography.kBold14.copyWith(
                  color: AppColors.kSkyBlue
                )
              ),
            ],
          ),
          SizedBox(height: AppSpacing.fiveVertical),
          /// **Hiring Tags**
          Row(
            children: [
              _buildTag(hiringTag),
              const SizedBox(width: 8),
              _buildTag(jobType),
            ],
          ),
          SizedBox(height: AppSpacing.tenVertical),
          /// **Location & Distance**
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  SvgPicture.asset(
                      AppAssets.kLocation,
                    height: 16,
                    width: 16,
                    color: Colors.grey,
                  ),
                  const SizedBox(width: 5),
                  Text(
                    location,
                    style: AppTypography.kLight14.copyWith(
                      color: AppColors.kWhite
                    ),
                  ),
                ],
              ),
              Text(
                distance,
                style: AppTypography.kLight14.copyWith(
                  color: AppColors.kWhite
                ),
              ),
            ],
          ),

          SizedBox(height: AppSpacing.tenVertical),

          /// **Date & Shift Timing**
          Row(
            children: [
              Row(
                children: [
                  const Icon(Icons.calendar_today, color: Colors.grey, size: 16),
                  const SizedBox(width: 5),
                  Text(
                    day,
                    style: AppTypography.kLight14.copyWith(
                      color: AppColors.kWhite
                    ),
                  ),
                  const SizedBox(width: 20,),
                  const Icon(Icons.access_time, color: Colors.grey, size: 16),
                  const SizedBox(width: 5),
                  Text(
                    shiftTime,
                    style: AppTypography.kLight14.copyWith(
                        color: AppColors.kWhite
                    ),
                  ),
                ],
              ),
            ],
          ),

          SizedBox(height: AppSpacing.tenVertical),

          /// **Required Persons**
          Text(
            requiredPersons,
            style: AppTypography.kBold14.copyWith(
                color: AppColors.kSkyBlue
            ),
          ),
        ],
      ),
    );
  }

  /// **Helper Method to Build Tag Widgets**
  Widget _buildTag(String text) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.grey[800],
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        text,
        style: const TextStyle(color: Colors.white, fontSize: 12),
      ),
    );
  }
}
